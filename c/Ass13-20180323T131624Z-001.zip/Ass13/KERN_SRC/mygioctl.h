#define magicnumber 'x'
#define BUF_CNT _IOR(magicnumber,1,int)
#define BUF_CLR _IO(magicnumber,2)
#define BUF_DISP _IO(magicnumber,3)
